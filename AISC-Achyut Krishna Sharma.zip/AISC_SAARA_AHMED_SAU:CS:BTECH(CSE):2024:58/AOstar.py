graph = {
    'A': [[('B',1)], [('C',1),('D',1)]],
    'B': [[('E',1)]],
    'C': [[('F',1)]],
    'D': [[('G',1)]],
    'E': [], 'F': [], 'G': []
}
h = {'A':5, 'B':2, 'C':1, 'D':1, 'E':0, 'F':0, 'G':0}
goal = 'E'

def ao_star(n):
    if n == goal: return 0
    if not graph[n]: return float('inf')
    costs = [
        sum(c + ao_star(ch) for ch,c in option)
        for option in graph[n]
    ]
    h[n] = min(costs)
    return h[n]

def solution(n, level=0):
    print("  "*level + n)
    if n == goal: return
    option = min(graph[n],
                 key=lambda o: sum(c+h[ch] for ch,c in o))
    for ch,_ in option:
        solution(ch, level+1)
cost = ao_star('A')

print("Start:", 'A')
print("Goal:", goal)
print("Optimal Cost:", cost)
print("\nSolution:")
solution('A')