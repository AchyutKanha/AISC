def bfs(graph, i_node):
    visited = []
    queue = []
    visited.append(i_node)
    queue.append(i_node)

    while len(queue) > 0:
        node = queue.pop(0)
        print(node)

        for neighbour in graph [node]:
            if neighbour not in visited:
                visited.append(neighbour)
                queue.append(neighbour)

graph = [[1,2], [0,3,4], [0,5], [1], [3], [2]]
bfs(graph, 0)
