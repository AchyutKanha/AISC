def steepest_hill_climbing(arr):
    current = 0

    while True:
        neighbors = [i for i in range(len(arr)) if i != current]

        best = current

        for i in neighbors:
            if arr[i] > arr[best]:
                best = i

        if best == current:
            break

        current = best

    return arr[current], current
arr = [1, 3, 5, 7, 6, 4, 2, 29,8,3]
peak, index = steepest_hill_climbing(arr)
print("Peak value:", peak)
print("Peak index:", index)
