MOD =1000000007
t=int(input())
for i in range(t):
    x=int(input())
    s=input().strip()
    length=len(s)
    for i in range(1,x+1):
        digit=int(s[i-1])
        length=(i+digit*(length-i))%MOD
        if len(s) < x:
            s += s[i +1:]*(digit-1)
    print(length)