
import random

def fitness(x):
    return x**3 + 1

def create_population(size):
    return [random.randint(0, 16) for _ in range(size)]

def selection(population):
    population.sort(key=fitness, reverse=True)
    return population[0], population[1]

def crossover(parent1, parent2):
    b1 = format(parent1, "05b")
    b2 = format(parent2, "05b")

    point = random.randint(1, 4)
    child = b1[:point] + b2[point:]

    return min(int(child, 2), 16)

def mutation(x, rate=0.1):
    if random.random() < rate:
        bit = random.randint(0, 4)
        chromosome = list(format(x, "05b"))

        chromosome[bit] = "1" if chromosome[bit] == "0" else "0"
        x = int("".join(chromosome), 2)

    return min(x, 16)

def genetic_algorithm():
    population_size = 6
    generations = 20

    population = create_population(population_size)

    for generation in range(generations):
        parent1, parent2 = selection(population)

        new_population = [parent1, parent2]

        while len(new_population) < population_size:
            child = crossover(parent1, parent2)
            child = mutation(child)
            new_population.append(child)

        population = new_population

        best = max(population, key=fitness)

        print(
            f"Generation {generation + 1}: "
            f"x = {best}, Fitness = {fitness(best)}"
        )

    best = max(population, key=fitness)

    print("\nOptimal Solution:")
    print("x =", best)
    print("Maximum Fitness =", fitness(best))


genetic_algorithm()
