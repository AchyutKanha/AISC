def ida_star(graph, heuristic, start, goal):
    threshold = heuristic[start]

    def search(node, g, threshold, path):
        f = g + heuristic[node]
        if f > threshold:
            return f
        if node == goal:
            return path
        minimum = float("inf")

        for neighbor, cost in graph[node]:
            if neighbor not in path:
                result = search(
                    neighbor,
                    g + cost,
                    threshold,
                    path + [neighbor]
                )
                if isinstance(result, list):
                    return result
                minimum = min(minimum, result)
        return minimum

    while True:
        result = search(start, 0, threshold, [start])
        if isinstance(result, list):
            return result
        if result == float("inf"):
            return None
        threshold = result

graph = {
    'A': [('B', 1), ('C', 4)],
    'B': [('D', 2), ('E', 5)],
    'C': [('F', 3)],
    'D': [('G', 2)],
    'E': [('G', 1)],
    'F': [('G', 2)],
    'G': []
}
heuristic = {
    'A': 5,
    'B': 4,
    'C': 4,
    'D': 2,
    'E': 1,
    'F': 2,
    'G': 0
}

start = 'A'
goal = 'G'
path = ida_star(graph, heuristic, start, goal)
if path:
    print("Path:", " -> ".join(path))
else:
    print("No path found")
