def dfs(graph, node, visited=None):
    if visited is None:
        visited = []
    visited.append(node)
    print(node)
    for neighbour in graph[node]:
        if neighbour not in visited:
            dfs(graph, neighbour, visited)
graph = [[1,2], [0,3,4], [0,5], [1], [3], [2]]
dfs(graph, 0)