import heapq
def astar(graph, start, goal, heuristic):
    open_list = [(0, start)]
    g_score = {start: 0}
    parent = {}

    while open_list:
        f, current = heapq.heappop(open_list)

        if current == goal:
            path = []

            while current in parent:
                path.append(current)
                current = parent[current]

            path.append(start)
            path.reverse()

            return path, g_score[goal]
        for neighbor, cost in graph[current]:
            new_g = g_score[current] + cost

            if neighbor not in g_score or new_g < g_score[neighbor]:
                g_score[neighbor] = new_g
                parent[neighbor] = current

                f_score = new_g + heuristic(neighbor, goal)

                heapq.heappush(open_list, (f_score, neighbor))

    return None, float("inf")
graph = {
    'A': [('B',1), ('C',4)],
    'B': [('D',2), ('E',5)],
    'C': [('E',1)],
    'D': [('G',5)],
    'E': [('G',2)],
    'G': []
}
def heuristic(node, goal):
    h = {
        'A': 7,
        'B': 6,
        'C': 3,
        'D': 4,
        'E': 1,
        'G': 0
    }

    return h[node]
path, cost = astar(graph, 'A', 'G', heuristic)

print("Path:", path)
print("Cost:", cost)