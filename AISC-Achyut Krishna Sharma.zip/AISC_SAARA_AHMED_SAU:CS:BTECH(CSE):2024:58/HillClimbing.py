def hill_climbing(arr):
    current = 0
    while current < len(arr) - 1:
        if arr[current + 1] > arr[current]:
            current += 1
        else:
            break
    return arr[current]
arr = [1, 3, 5, 7, 6, 4, 2]
result = hill_climbing(arr)
print("Peak value:", result)