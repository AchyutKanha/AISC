def steepest_hill_climbing(arr):
    current = 0
    while True:
        neighbors = []
        if current > 0:
            neighbors.append(current - 1)
        if current < len(arr) - 1:
            neighbors.append(current + 1)
        best = current
        for i in neighbors:
            if arr[i] > arr[best]:
                best = i
        if best == current:
            break
        current = best
    return arr[current], current
arr = [1, 3, 5, 7, 6, 4, 2, 29,8,3]
peak, index = steepest_hill_climbing(arr)
print("Peak value:", peak)
print("Peak index:", index)
