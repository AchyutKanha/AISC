def dfs_directed(graph):
    visited = set()   
    def dfs_visit(node):
        visited.add(node)
        print(node, end=" ") 
        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                dfs_visit(neighbor)
    for vertex in graph:
        if vertex not in visited:
            dfs_visit(vertex)
graph = {
    'A': ['B', 'C'],
    'B': ['D'],
    'C': ['E'],
    'D': [],
    'E': ['B']
}
print("DFS Traversal:")
dfs_directed(graph)